package com.feedbackservice.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.feedbackservice.dto.FeedbackDto;
import com.feedbackservice.dto.UserDTO;
import com.feedbackservice.entity.Feedback;
import com.feedbackservice.service.FeedbackService;

@RestController
@RequestMapping("/api/feedback")
public class FeedbackController {

    private final FeedbackService feedbackService;

    @Autowired
    public FeedbackController(FeedbackService feedbackService) {
        this.feedbackService = feedbackService;
    }

	/*
	 * @PostMapping("/submit/{userName}") public Feedback
	 * submitFeedback(@PathVariable String userName,@RequestBody FeedbackDto
	 * feedbackDTO) { return feedbackService.saveFeedback(userName, feedbackDTO); }
	 */

    @GetMapping("/{feedbackId}")
    public Feedback getFeedback(@PathVariable Integer feedbackId) {
        return feedbackService.getFeedback(feedbackId);
    }

    @GetMapping("/all")
    public List<Feedback> getAllFeedback() {
        return feedbackService.getAllFeedback();
    }

    @PutMapping("/{feedbackId}")
    public Feedback updateFeedback(@PathVariable Integer feedbackId, @RequestBody FeedbackDto feedbackDTO) {
        return feedbackService.updateFeedback(feedbackId, feedbackDTO);
    }

    @DeleteMapping("/{feedbackId}")
    public void deleteFeedback(@PathVariable Integer feedbackId) {
        feedbackService.deleteFeedback(feedbackId);
    }
    
    @PostMapping("/getplacefortour/{placeId}/{userId}")
	public String getPlacefortour (@PathVariable(name="placeId") Integer placeId, @PathVariable(name="userId") Integer userId, @RequestBody FeedbackDto feedbackdto) {
		return feedbackService.getPlacefortour(placeId, userId, feedbackdto);
	}
    
    @PostMapping("/getuserdto/{feedbackId}")
    public UserDTO getUserDTO (@PathVariable(name="feedbackId") Integer feedbackId) {
    	return feedbackService.getUserDTO(feedbackId);
    }
    
    
}
