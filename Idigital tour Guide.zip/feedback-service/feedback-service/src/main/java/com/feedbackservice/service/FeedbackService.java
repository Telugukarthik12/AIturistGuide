package com.feedbackservice.service;

import java.util.List;

import com.feedbackservice.dto.FeedbackDto;
import com.feedbackservice.dto.UserDTO;
import com.feedbackservice.entity.Feedback;

public interface FeedbackService {

//	Feedback saveFeedback(String userName,FeedbackDto feedbackDTO);

	Feedback getFeedback(Integer feedbackId);

	List<Feedback> getAllFeedback();

	Feedback updateFeedback(Integer feedbackId, FeedbackDto feedbackDTO);

	public void deleteFeedback(Integer feedbackId);

	String getPlacefortour(Integer placeId, Integer userId, FeedbackDto feedbackdto);

	UserDTO getUserDTO(Integer feedbackId);

}
