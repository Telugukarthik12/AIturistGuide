package com.tourplan.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tourplan.entity.TourPlan;

public interface TourPlanRepository extends JpaRepository<TourPlan, Integer> {

}
