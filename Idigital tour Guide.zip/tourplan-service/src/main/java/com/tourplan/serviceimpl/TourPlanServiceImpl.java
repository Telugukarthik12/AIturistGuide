package com.tourplan.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.tourplan.dto.HelperDTO;
import com.tourplan.dto.PlaceDTO;
import com.tourplan.dto.TourPlanDTO;
import com.tourplan.dto.UserDTO;
import com.tourplan.entity.TourPlan;
import com.tourplan.openfeign.PlaceClient;
import com.tourplan.openfeign.UserClient;
import com.tourplan.repository.TourPlanRepository;
import com.tourplan.service.TourPlanService;

@Service
public class TourPlanServiceImpl implements TourPlanService {

	@Autowired
	TourPlanRepository tourRepo;

	@Autowired
	PlaceClient placeClients;

	@Autowired
	UserClient userClients;

	@Override
	public ResponseEntity<String> createTour(Integer userId, TourPlanDTO tourPlanDto) {
		List<Integer> placeIds = placeClients.getPlaceList().getBody();
		Integer userId1 = userClients.getUserForClient(userId);
//		System.out.println(userId1);
//		System.out.println(placeIds);
		TourPlan tourPlan = new TourPlan();
		tourPlan.setStartDate(tourPlanDto.getStartDate());
		tourPlan.setEndDate(tourPlanDto.getEndDate());
		tourPlan.setUserId(userId1);
		tourPlan.setPlaceId(placeIds);
		tourRepo.save(tourPlan);
		return new ResponseEntity<>("Created", HttpStatus.CREATED);
	}

	@Override
	public ResponseEntity<HelperDTO> getTourDetails(Integer tourId) {
		TourPlan tourPlan = tourRepo.findById(tourId).get();
		UserDTO userDTO = userClients.getUserById(tourPlan.getUserId()).getBody();
		List<PlaceDTO> body = placeClients.getListOfPlaceDTOByPlaceId(tourPlan.getPlaceId()).getBody();
		
		HelperDTO helperDTO = new HelperDTO();
		
		UserDTO userDTO2 = new UserDTO();
		userDTO2.setUserName(userDTO.getUserName());
		userDTO2.setUserEmail(userDTO.getUserEmail());
		userDTO2.setNumber(userDTO.getNumber());
		userDTO2.setAddress(userDTO.getAddress());
		
		helperDTO.setUserDto(userDTO2);
		helperDTO.setPlaceDto(body);
		return new ResponseEntity<>(helperDTO, HttpStatus.OK);
	}

}
