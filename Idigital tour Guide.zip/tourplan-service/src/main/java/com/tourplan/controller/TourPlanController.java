package com.tourplan.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tourplan.dto.HelperDTO;
import com.tourplan.dto.TourPlanDTO;
import com.tourplan.service.TourPlanService;

@RestController
@RequestMapping("/tourplan")
public class TourPlanController {

	@Autowired
	TourPlanService tourPlanService;

	@PostMapping("/createtour/{userId}")
	public ResponseEntity<String> createTour(@PathVariable(name= "userId") Integer userId, @RequestBody TourPlanDTO tourPlanDto) {
		return tourPlanService.createTour(userId, tourPlanDto);
	}
	
	@GetMapping("/gettourdetails/{tourId}")
	public ResponseEntity<HelperDTO> getTourDetails (@PathVariable(name = "tourId")Integer tourId){
		return tourPlanService.getTourDetails(tourId);
	}
}
