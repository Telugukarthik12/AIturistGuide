package com.tourplan.service;

import org.springframework.http.ResponseEntity;

import com.tourplan.dto.HelperDTO;
import com.tourplan.dto.TourPlanDTO;

public interface TourPlanService {

	ResponseEntity<String> createTour(Integer userId, TourPlanDTO tourPlanDto);

	ResponseEntity<HelperDTO> getTourDetails(Integer tourId);

}
