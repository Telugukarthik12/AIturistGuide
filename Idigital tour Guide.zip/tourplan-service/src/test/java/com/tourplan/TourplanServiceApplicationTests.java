package com.tourplan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourplanServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
